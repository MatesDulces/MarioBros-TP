package Background;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

public class Background {
    private Image backgroundImage;
    private int x, y;

    public Background(String imagePath) {
        this.backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
        this.x = 0;
        this.y = 0;
    }

    public void draw(Graphics g) {
        g.drawImage(backgroundImage, x, y, null);
    }

    public void scroll(int dx) {
        x -= dx;
        if (x < -backgroundImage.getWidth(null)) {
            x = 0;
        }
    }
}

