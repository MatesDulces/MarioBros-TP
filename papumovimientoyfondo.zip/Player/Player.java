package Player;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ImageIcon;

public class Player implements KeyListener {
    private int x, y;
    private int velocityX, velocityY;
    private boolean jumping;
    private Image playerImage;
    private final int GRAVITY = 1;

    public Player(int startX, int startY) {
        this.x = startX;
        this.y = startY;
        this.velocityX = 0;
        this.velocityY = 0;
        this.jumping = false;
        this.playerImage = new ImageIcon(getClass().getResource("/resources/player.png")).getImage();
    }

    public void update() {
        x += velocityX;
        y += velocityY;

        if (!jumping) {
            velocityY += GRAVITY;
        }

        if (y > 400) { // Suelo
            y = 400;
            velocityY = 0;
            jumping = false;
        }
    }

    public void draw(Graphics g) {
        g.drawImage(playerImage, x, y, null);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            velocityX = -5;
        } else if (key == KeyEvent.VK_RIGHT) {
            velocityX = 5;
        } else if (key == KeyEvent.VK_SPACE && !jumping) {
            velocityY = -15;
            jumping = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT) {
            velocityX = 0;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // No se usa en este caso
    }
}
