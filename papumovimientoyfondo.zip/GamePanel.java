import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import Background.Background;
import Player.Player;

public class GamePanel extends JPanel implements ActionListener {
    private Player player;
    private Background background;
    private Timer timer;

    public GamePanel() {
        this.player = new Player(100, 400);
        this.background = new Background("C:\\Users\\Alumno\\eclipse-workspace\\GICHI MICHI WOO\\src\\vecteezy_summer-nature-landscape-cartoon-game-background_12746789.jpg");

        this.timer = new Timer(16, this);
        this.timer.start();

        this.setFocusable(true);
        this.addKeyListener(player);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        background.draw(g);
        player.draw(g);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        player.update();
        background.scroll(5);
        repaint();
    }
}

