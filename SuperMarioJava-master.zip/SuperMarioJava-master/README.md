SuperMarioJava
==============

Basic Super Mario Bros made in Java.
The aim of this game is to collect all the coins of the levels.

Go here if you want to see a gameplay:
http://programmingheroes.blogspot.com.es/2013/05/remake-super-mario-java.html

-----------------------------------------------------------------------------

Básico juego de Super Mario Bros hecho en Java.
El objetivo es recolectar todas las monedas de cada nivel.

Para ver un vídeo del juego en funcionamiento puedes visitar:
http://programmingheroes.blogspot.com.es/2013/05/remake-super-mario-java.html

-----------------------------------------------------------------------------

## Screenshots

![](https://images-blogger-opensocial.googleusercontent.com/gadgets/proxy?url=http://1.bp.blogspot.com/-khsDa-q-Dd8/U5pM21ZJpdI/AAAAAAAAK0A/2LkrXeCV8f8/s1600/Sin%2Bt%25C3%25ADtulo.png&container=blogger&gadget=a&rewriteMime=image/*)

![](https://images-blogger-opensocial.googleusercontent.com/gadgets/proxy?url=http://3.bp.blogspot.com/-iQHGVdGC98I/U5pM22u2jkI/AAAAAAAAKz0/OWCP6X6uVJ0/s1600/Sin%2Bt%25C3%25ADtulo1.png&container=blogger&gadget=a&rewriteMime=image/*)

![](https://images-blogger-opensocial.googleusercontent.com/gadgets/proxy?url=http://3.bp.blogspot.com/-cLKQMJDKJIs/U5pM2xMnu_I/AAAAAAAAKzw/O3oger-2b3g/s1600/Sin%2Bt%25C3%25ADtulo2.png&container=blogger&gadget=a&rewriteMime=image/*)
